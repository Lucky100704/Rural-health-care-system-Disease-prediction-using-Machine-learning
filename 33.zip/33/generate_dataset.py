import pandas as pd
import numpy as np

# Set random seed for reproducibility
np.random.seed(42)

# Generate synthetic data
data_size = 1000
data = pd.DataFrame({
    'age': np.random.randint(10, 80, size=data_size),  # Age between 10 and 80
    'gender': np.random.choice([0, 1], size=data_size),  # 0 = Female, 1 = Male
    'smoking_status': np.random.choice([0, 1], size=data_size),  # 0 = Non-Smoker, 1 = Smoker
    'family_history': np.random.choice([0, 1], size=data_size),  # 0 = No, 1 = Yes
    'wheezing': np.random.choice([0, 1], size=data_size),  # 0 = No, 1 = Yes
    'shortness_of_breath': np.random.choice([0, 1], size=data_size),  # 0 = No, 1 = Yes
    'chest_tightness': np.random.choice([0, 1], size=data_size),  # 0 = No, 1 = Yes
    # Target variable: Asthma (1 = Positive, 0 = Negative)
    'asthma': np.random.choice([0, 1], size=data_size, p=[0.6, 0.4])  # 60% negative, 40% positive
})

# Print the first few rows of the generated data to check
print(data.head())

# Save dataset to CSV for reuse
data.to_csv('synthetic_asthma_data.csv', index=False)

print("Synthetic dataset created and saved as 'synthetic_asthma_data.csv'!")
