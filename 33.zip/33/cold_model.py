import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import joblib

# Step 1: Create a dataset (you can replace this with a larger dataset)
data = {
    "Fever": [1, 1, 0, 0, 1, 1, 0, 0, 1, 1],
    "Cough": [1, 1, 1, 0, 0, 1, 0, 1, 1, 0],
    "Sore_Throat": [1, 0, 1, 0, 1, 0, 0, 1, 1, 0],
    "Runny_Nose": [0, 1, 1, 1, 1, 0, 1, 1, 0, 1],
    "Headache": [1, 1, 0, 0, 0, 1, 1, 0, 1, 0],
    "Cold_Type": ["Viral", "Viral", "Bacterial", "Bacterial", "Allergy", "Viral", "Allergy", "Bacterial", "Viral", "Allergy"]
}

# Step 2: Prepare the data
df = pd.DataFrame(data)
X = df.drop("Cold_Type", axis=1)  # Features (symptoms)
y = df["Cold_Type"]  # Target (cold type)

# Encode the target variable (Cold_Type) into numeric labels (0, 1, 2 for different types)
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Step 3: Check class distribution
print("Class distribution in the target:")
print(pd.Series(y_encoded).value_counts())

# Step 4: Split the data into training and testing sets
# Using test_size=0.3 to ensure proper distribution
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.3, random_state=42, stratify=y_encoded)

# Step 5: Train a RandomForest classifier
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Step 6: Save both the model and label encoder in a single .pkl file
model_and_encoder = {"model": model, "label_encoder": label_encoder}
joblib.dump(model_and_encoder, 'cold_type_model_and_encoder.pkl')  # Save both in a single file

print("Model and label encoder saved as 'cold_type_model_and_encoder.pkl'")
