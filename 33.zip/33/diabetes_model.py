import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load the diabetes dataset
data = pd.read_csv('diabetes.csv')

# Select features and target
X = data[['Glucose', 'SkinThickness', 'Insulin', 'Age']]  # Features: Glucose, SkinThickness, Insulin, Age
y = data['Outcome']  # Target: Diabetes Outcome (0 or 1)

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Train a RandomForest classifier
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Save the trained model using joblib
joblib.dump(model, 'diabetes_model.pkl')

print("Model saved as 'diabetes_model.pkl'")
