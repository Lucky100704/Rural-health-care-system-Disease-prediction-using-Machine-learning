import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle

# Load the synthetic dataset
data = pd.read_csv('synthetic_asthma_data.csv')

# Features (X) and Target (y)
X = data.drop(columns=['asthma'])  # Input features
y = data['asthma']  # Target variable

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model_asthma = RandomForestClassifier(random_state=42)
model_asthma.fit(X_train, y_train)

# Save the trained model
with open('asthma_model.pkl', 'wb') as file:
    pickle.dump(model_asthma, file)

print("Asthma Prediction Model Trained and Saved as 'asthma_model.pkl'!")
