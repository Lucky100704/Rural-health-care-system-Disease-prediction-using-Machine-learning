import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load the synthetic dataset
data = pd.read_csv('blood_pressure_data.csv')

# Split the dataset into features (X) and target (y)
X = data[['systolic', 'diastolic']]  # Features: systolic and diastolic BP
y = data['target']  # Target: BP category (Normal, Elevated, Hypertension, etc.)

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a RandomForest classifier
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Save the trained model using joblib
joblib.dump(model, 'bp_model.pkl')

print("Model saved as 'bp_model.pkl'")
